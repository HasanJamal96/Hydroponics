<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="google-signin-client_id" content="897355864281-7nc9kdpmhjp1uafapqvpr8d9e822l5lt.apps.googleusercontent.com">
<link rel="shortcut icon" type="image/png" href="<?php echo base_url() . 'assets/'; ?>images/10.png">
<title>HYDROPHONIC</title>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
<!-- <link rel="stylesheet" type="text/css" href="css/w3.css"> -->
<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/'; ?>css/neon-forms.css">
<link rel="stylesheet" type="text/css" href="<?php echo base_url() . 'assets/'; ?>css/style.css">
<link rel="stylesheet" href="<?php echo base_url() . 'assets/'; ?>css/animate.min.css">
<link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">

<link href='https://fonts.googleapis.com/css?family=inherit' rel='stylesheet'>
<link href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" rel="stylesheet">
<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/fancybox/2.1.5/jquery.fancybox.min.css" media="screen">

<link rel="stylesheet" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/buttons/2.0.1/css/buttons.dataTables.min.css">
