<footer class="main">
© 2019-2022 LuxBalance Lighting Limited. All rights reserved
</footer>